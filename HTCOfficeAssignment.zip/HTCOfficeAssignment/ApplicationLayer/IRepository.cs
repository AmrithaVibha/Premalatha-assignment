﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
    public interface IRepository<T> where T : class
    {
        Task <T> GetAllAsync();
        Task<string> AddAsync(T entity);
        //Task<T> GetByIdAsync(long id);
        Task<List<T>>GetListOfItemsById(int id);
        Task<string> UpdateAsync(T entity);
        Task<string> DeleteAsync(int id);
    }
}
