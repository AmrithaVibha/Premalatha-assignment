﻿using CoreLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer
{
    public interface IControlTypeRepository : IRepository<List<ControlTypeModel>>    {
      
    }
    public interface IUnitOfWork
    {
        IControlTypeRepository Controls { get; }
    }
}
