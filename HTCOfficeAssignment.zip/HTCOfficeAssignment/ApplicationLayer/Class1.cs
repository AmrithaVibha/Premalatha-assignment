﻿namespace ApplicationLayer
{
    public class Class1
    {

    }
}