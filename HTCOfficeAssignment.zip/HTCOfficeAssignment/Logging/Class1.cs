﻿namespace Logging
{
    public class Class1
    {

    }
}