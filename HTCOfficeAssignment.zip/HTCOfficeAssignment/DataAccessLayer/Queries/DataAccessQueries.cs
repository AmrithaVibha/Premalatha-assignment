﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Queries
{
    public class DataAccessQueries
    {
        public static string AllControls => "SELECT * FROM [ControlType]";
        public static string SaveControlDetails => "INSERT INTO [ControlDetails] ([ControlName], [Label], [TxtDetailsMaxSize],[DDList],[isMandatory],[DisplayOrder],[FormId],[GridColumn])" +
            "         VALUES (@ControlName,@Label,@TxtDetailsMaxSize,@DDList,@isMandatory,@DisplayOrder,@FormId,@GridColumn)";

        public static string GetConfigurationFormDetails => "SELECT * FROM [ControlDetails] where [FormId]=@FormId";
        public static string DeleteControl => "DELETE FROM [ControlDetails] WHERE [Id]=@Id";
        public static string EditControl => "UPDATE [ControlDetails] SET  [ControlName] = @ControlName,[Label]=@Label,[TxtDetailsMaxSize]=@TxtDetailsMaxSize,[DDList]=@DDList,[isMandatory]=@isMandatory,[DisplayOrder]=@DisplayOrder,[FormId]=@FormId,[GridColumn]=@GridColumn WHERE [Id]=@Id;";

    }
}
