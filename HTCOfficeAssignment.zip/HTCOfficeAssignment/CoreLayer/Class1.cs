﻿namespace CoreLayer
{
    public class Class1
    {

    }
}