﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreLayer.Entities
{
    public class ControlDetailsModel
    {
        public int? Id { get; set; }
        public string ControlName { get; set; }
        public int GridColumn { get; set; }
        public string Label { get; set; }   
        public int? TxtDetailsMaxSize { get; set; }
        public string DDList { get; set; }      
        public bool isMandatory { get; set; }
        public int DisplayOrder { get; set; }
        public int FormId { get; set; }



    }
}
