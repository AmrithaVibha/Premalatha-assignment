﻿using ApplicationLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfrastructureLayer.Repository
{
    public class UnitOfWork2 : IUnitOfWork2
    {
        public UnitOfWork2(IControlDetailsInterface controlDetailsRepository)
        {
            ControlsDetails = controlDetailsRepository;

        }
        public IControlDetailsInterface ControlsDetails { get; set; }


    }

}
