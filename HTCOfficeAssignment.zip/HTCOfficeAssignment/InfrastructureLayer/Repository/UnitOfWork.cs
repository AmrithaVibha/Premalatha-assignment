﻿using ApplicationLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfrastructureLayer.Repository
{
    public class UnitOfWork:IUnitOfWork
    {
        public UnitOfWork(IControlTypeRepository contactRepository)
        {
            Controls = contactRepository;
           
        }
        public IControlTypeRepository Controls { get; set; }

       
    }
}
