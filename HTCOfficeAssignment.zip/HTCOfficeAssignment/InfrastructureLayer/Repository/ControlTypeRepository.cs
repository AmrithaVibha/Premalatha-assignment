﻿using ApplicationLayer;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoreLayer.Entities;
using Dapper;
using DataAccessLayer.Queries;

namespace InfrastructureLayer.Repository
{
    public class ControlTypeRepository:IControlTypeRepository
    {
        private readonly IConfiguration configuration;
        public ControlTypeRepository(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public Task<string> AddAsync(ControlTypeModel entity)
        {
            throw new NotImplementedException();
        }

        public Task<string> AddAsync(List<ControlTypeModel> entity)
        {
            throw new NotImplementedException();
        }

        public Task<string> DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<List<ControlTypeModel>> GetAllAsync()
        {
            using (IDbConnection connection = new SqlConnection(configuration.GetConnectionString("DBConnection")))
            {
                connection.Open();
                var result = await connection.QueryAsync<ControlTypeModel>(DataAccessQueries.AllControls);
                return result.ToList();
            }
        }

        public Task<List<List<ControlTypeModel>>> GetListOfItemsById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<string> UpdateAsync(List<ControlTypeModel> entity)
        {
            throw new NotImplementedException();
        }
    }
}
