﻿using ApplicationLayer;
using CoreLayer.Entities;
using DataAccessLayer.Queries;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Dapper;
using static Dapper.SqlMapper;
using Microsoft.SqlServer.Server;

namespace InfrastructureLayer.Repository
{
    public class ControlDetailsRepository : IControlDetailsInterface
    {

        private readonly IConfiguration configuration;
        public ControlDetailsRepository(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public async Task<string> AddAsync(ControlDetailsModel entity)
        {
            using (IDbConnection connection = new SqlConnection(configuration.GetConnectionString("DBConnection")))
            {
                connection.Open();
                var result = await connection.ExecuteAsync(DataAccessQueries.SaveControlDetails,entity);
                return result.ToString();
            }

        }

        public async Task<string> DeleteAsync(int id)
        {
            using (IDbConnection connection = new SqlConnection(configuration.GetConnectionString("DBConnection")))
            {
                connection.Open();
                var result = await connection.ExecuteAsync(DataAccessQueries.DeleteControl,new { Id = id });
                return result.ToString();
            }
        }

        public Task<ControlDetailsModel> GetAllAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<List<ControlDetailsModel>> GetListOfItemsById(int formId)
        {
            using (IDbConnection connection = new SqlConnection(configuration.GetConnectionString("DBConnection")))
            {
                connection.Open();
                var result = await connection.QueryAsync<ControlDetailsModel>(DataAccessQueries.GetConfigurationFormDetails,new { FormId = formId });
                return result.ToList();
            }

        }

        public async Task<string> UpdateAsync(ControlDetailsModel entity)
        {
            using (IDbConnection connection = new SqlConnection(configuration.GetConnectionString("DBConnection")))
            {
                connection.Open();
                var result = await connection.ExecuteAsync(DataAccessQueries.EditControl, entity);
                return result.ToString();
            }
        }
    }
}
