﻿namespace InfrastructureLayer
{
    public class Class1
    {

    }
}