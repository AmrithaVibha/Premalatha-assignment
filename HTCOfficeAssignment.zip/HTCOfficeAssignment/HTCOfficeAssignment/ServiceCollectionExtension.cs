﻿using ApplicationLayer;
using InfrastructureLayer.Repository;

namespace HTCOfficeAssignment
{
    public static class ServiceCollectionExtension
    {
        public static void RegisterServices(this IServiceCollection services)
        {
            services.AddTransient<IControlTypeRepository, ControlTypeRepository>();
            services.AddTransient<IUnitOfWork, UnitOfWork>();
            services.AddScoped<IUnitOfWork2, UnitOfWork2>();
            services.AddTransient<IControlDetailsInterface, ControlDetailsRepository>();
        }
    }
}
