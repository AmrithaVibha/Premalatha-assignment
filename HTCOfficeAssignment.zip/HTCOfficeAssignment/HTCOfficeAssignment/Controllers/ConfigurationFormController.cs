﻿using ApplicationLayer;
using CoreLayer.Entities;
using HTCOfficeAssignment.Model;
using Logging;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Data.SqlClient;

namespace HTCOfficeAssignment.Controllers
{
    public class ConfigurationFormController:BaseApiController
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IUnitOfWork2 _unitOfWork2;
        public ConfigurationFormController(IUnitOfWork unitOfWork, IUnitOfWork2 unitOfWork2)
        {
            this._unitOfWork = unitOfWork;
            this._unitOfWork2 = unitOfWork2;
        }
        [HttpGet]
        public async Task<ApiResponse<List<ControlTypeModel>>> GetAll()
        
        {
            var apiResponse = new ApiResponse<List<ControlTypeModel>>();

            try
            {
                var data = await _unitOfWork.Controls.GetAllAsync();
                apiResponse.Success = true;
                apiResponse.Result = data.ToList();
            }
            catch (SqlException ex)
            {
                apiResponse.Success = false;
                apiResponse.Message = ex.Message;
                Logger.Instance.Error("SQL Exception:", ex);
            }
            catch (Exception ex)
            {
                apiResponse.Success = false;
                apiResponse.Message = ex.Message;
               Logger.Instance.Error("Exception:", ex);
            }

            return apiResponse;
        }
        [HttpPost]
        [Route("postcontroldetails")]
        public async Task<ApiResponse<string>> PostControlDetails(ControlDetailsModel controlDetails)
        {
            var apiResponse = new ApiResponse<string>();

            try
            {
                if (controlDetails != null)
                {
                    var data = await _unitOfWork2.ControlsDetails.AddAsync(controlDetails);
                    apiResponse.Success = true;
                    apiResponse.Result = data;
                }
            }
            catch (SqlException ex)
            {
                apiResponse.Success = false;
                apiResponse.Message = ex.Message;
                Logger.Instance.Error("SQL Exception:", ex);
            }
            catch (Exception ex)
            {
                apiResponse.Success = false;
                apiResponse.Message = ex.Message;
                Logger.Instance.Error("Exception:", ex);
            }

            return apiResponse;
        }
        [HttpGet]
        [Route("formcontrolslist")]
        public async Task<ApiResponse<List<ControlDetailsModel>>> GetParticularFormControl(int id)
        {
            var apiResponse = new ApiResponse<List<ControlDetailsModel>>();

            try
            {
                var data = await _unitOfWork2.ControlsDetails.GetListOfItemsById(id);
                apiResponse.Success = true;
                apiResponse.Result = data.ToList();
            }
            catch (SqlException ex)
            {
                apiResponse.Success = false;
                apiResponse.Message = ex.Message;
                Logger.Instance.Error("SQL Exception:", ex);
            }
            catch (Exception ex)
            {
                apiResponse.Success = false;
                apiResponse.Message = ex.Message;
                Logger.Instance.Error("Exception:", ex);
            }

            return apiResponse;
        }
        [HttpPost]
        [Route("editcontrols")]
        public async Task<ApiResponse<string>> EditControls(ControlDetailsModel controlDetails)
        {
            var apiResponse = new ApiResponse<string>();

            try
            {
                if (controlDetails != null)
                {
                    var data = await _unitOfWork2.ControlsDetails.UpdateAsync(controlDetails);
                    apiResponse.Success = true;
                    apiResponse.Result = data;
                }
            }
            catch (SqlException ex)
            {
                apiResponse.Success = false;
                apiResponse.Message = ex.Message;
                Logger.Instance.Error("SQL Exception:", ex);
            }
            catch (Exception ex)
            {
                apiResponse.Success = false;
                apiResponse.Message = ex.Message;
                Logger.Instance.Error("Exception:", ex);
            }

            return apiResponse;
        }
        [HttpGet]
        [Route("deletecontrols")]
        public async Task<ApiResponse<string>> DeleteControls(int Id)
        {
            var apiResponse = new ApiResponse<string>();

            try
            {
                
                    var data = await _unitOfWork2.ControlsDetails.DeleteAsync(Id);
                    apiResponse.Success = true;
                    apiResponse.Result = data;
                
            }
            catch (SqlException ex)
            {
                apiResponse.Success = false;
                apiResponse.Message = ex.Message;
                Logger.Instance.Error("SQL Exception:", ex);
            }
            catch (Exception ex)
            {
                apiResponse.Success = false;
                apiResponse.Message = ex.Message;
                Logger.Instance.Error("Exception:", ex);
            }

            return apiResponse;
        }
    }
}
