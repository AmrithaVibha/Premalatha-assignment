﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HTCOfficeAssignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [TypeFilter(typeof(AuthorizationFilterAttribute))]
    public class BaseApiController : ControllerBase
    {
    }
}
