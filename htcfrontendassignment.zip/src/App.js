import logo from './logo.svg';
import './App.css';
import Index from './Components/Index';
import ConfigurationForm from './Components/ConfigurationForm';
import { Routes, Route } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route index Component={Index} ></Route>
      <Route path="configurationform/:id" Component={ConfigurationForm}></Route>
     
     </Routes>
    </div>
  );
}

export default App;
