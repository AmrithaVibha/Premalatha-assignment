import axios from "axios";
const axiosInstance=axios.create({
    baseURL:"https://localhost:7210/",
    timeout:50000,
})

axiosInstance.interceptors.request.use(function (config) {    
    config.headers.Authorization = "04577BA6-3E32-456C-B528-E41E20D28D79";    
    return config;
})

export default axiosInstance;