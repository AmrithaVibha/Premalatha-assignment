import axiosInstance from './axios';
import React from 'react';

const configurationFormService = {
   async dataFetching() {
   return await  axiosInstance.get('api/ConfigurationForm' )
          .then(response => {
            // handle success
            console.log(response.data.result);
            return response.data.result;        
          })
          .catch(error => {
            // handle error
            console.log(error);
          })
      },
      async postControlDetails(data) {
        return await  axiosInstance.post('api/ConfigurationForm/postcontroldetails',data)
               .then(response => {
                 // handle success
                 console.log(response.data.result);
                 return response.data.result;        
               })
               .catch(error => {
                 // handle error
                 console.log(error);
               })
           },
           async getFormControlsById(id) {
            return await  axiosInstance.get('api/ConfigurationForm/formcontrolslist?id='+parseInt(id) )
                   .then(response => {
                     // handle success
                     console.log(response.data.result);
                     return response.data.result;        
                   })
                   .catch(error => {
                     // handle error
                     console.log(error);
                   })
               },
               async deleteControls(Id) {
                return await  axiosInstance.get('api/ConfigurationForm/deletecontrols?Id='+Id)
                       .then(response => {
                         // handle success
                         console.log(response.data.result);
                         return response.data.result;        
                       })
                       .catch(error => {
                         // handle error
                         console.log(error);
                       })
                   },
                   async editControls(data) {
                    return await  axiosInstance.post('api/ConfigurationForm/editcontrols',data)
                           .then(response => {
                             // handle success
                             console.log(response.data.result);
                             return response.data.result;        
                           })
                           .catch(error => {
                             // handle error
                             console.log(error);
                           })
                       },
    
};

export default configurationFormService;
