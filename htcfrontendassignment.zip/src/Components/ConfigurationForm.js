import React, { useEffect, useState,useRef } from "react";
import bootstrap from "bootstrap";
import "bootstrap/dist/css/bootstrap.css";
import configurationFormService from "../Service/axiosService";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
const ConfigurationForm = () => {
  const [controlTypes, setControlTypes] = useState([]);
  const [controlSelected, setControlSelected] = useState("TextBox");
  const [label, setLabel] = useState("");
  const [gridColumns, setGridColumns] = useState("");
  const [maxSize, setMaxSize] = useState(0);
  const [displayOrder, setDisplayOrder] = useState(0);
  const [ddDetails, setDdDetails] = useState("");  
  const [isMandatory, setIsMandatory] = useState("");
  const [formDataByFormId, setFormDataByFormId] = useState([]);
  const [ddDetailsToPreview, setDDDetailsToPreview] = useState([]);
  const[id,setId]=useState(0);
  const controlId = useRef();
  let ddDetailsList = [];
  var formId = useParams("id");
  
  const handleSelect = (e) => {
    console.log(e.target.value, "ddSelected");
    setControlSelected(e.target.value);
  };
  const handleClear = () => {
    setControlSelected("TextBox");
    setLabel("");
    setGridColumns(0);
    setMaxSize(0);
    setDisplayOrder(0);
    setDdDetails("");
   
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const controlDetails = {
     Id: id===""?null:parseInt(id),
      ControlName: controlSelected,
      GridColumn:parseInt(gridColumns),
      Label: label,
      TxtDetailsMaxSize:maxSize===undefined?null:parseInt(maxSize),
      DDList: ddDetails,     
      DateTimeControl: "",
      isMandatory: isMandatory,
      DisplayOrder:parseInt(displayOrder),
      FormId:parseInt(formId.id),
    };
    var element = document.getElementById("submitBtn");
  if(element.classList.contains("update")){
  var data = await configurationFormService.editControls(controlDetails)
  .then(async () => {
    var dataById = await configurationFormService.getFormControlsById(
      formId.id
    );
    console.log(dataById, "databyid");
    setFormDataByFormId(dataById);
  });
}
else{

    
    console.log(controlDetails);
    var data = await configurationFormService
      .postControlDetails(controlDetails)
      .then(async () => {
        var dataById = await configurationFormService.getFormControlsById(
          formId.id
        );
        console.log(dataById, "databyid");
        setFormDataByFormId(dataById);
      });
    console.log(data);
    if (data && data.success) {
      alert("Success");
    }
  }
 element.classList.remove("update");
  };
  useEffect(() => {
    const GetData = async () => {
      var data = await configurationFormService
        .dataFetching()
        .then(async (res) => {
          console.log(res, "api fetch");
          setControlTypes(res);
          var dataById = await configurationFormService.getFormControlsById(
            formId.id
          );
          console.log(dataById, "databyid");

          setFormDataByFormId(dataById);
        });
    };
    GetData();
  }, []);
const  handleDelete =async(Id)=>{
  var data = await configurationFormService.deleteControls(Id)
  .then(async () => {
    var dataById = await configurationFormService.getFormControlsById(
      formId.id
    );
    console.log(dataById, "databyid");
    setFormDataByFormId(dataById);
  });
}
const handleEdit=async(data)=>{
  setControlSelected(data.controlName);
  setLabel(data.label);
  setGridColumns(data.gridColumn);
  setMaxSize(data.TxtDetailsMaxSize);
  setDisplayOrder(data.displayOrder);
  setDdDetails(data.ddList);
  var element = document.getElementById("submitBtn");
  element.classList.add("update");
  setId(data.id);
 
}

  console.log(controlTypes, "usestate");
  return (
    <>
      <div className="container">
        <form>
          <div className="card">
            <div
              className="card-header"
              style={{ backgroundColor: "lightblue" }}
            >
              Create/Edit Event Controls
            </div>
            <div className="card-body col-lg-12 row">
              <div className="mb-3 col-lg-6">
                <label for="multiple-checkboxes" className="form-label">
                  Control Type
                </label>
                <select
                  id="multiple-checkboxes"
                  className="form-control form-select"
                  onChange={(e) => handleSelect(e)}
                >
                  {controlTypes &&
                    controlTypes.length > 0 &&
                    controlTypes.map((item) => {
                      return (
                        <option value={item.Id}>{item.controlType}</option>
                      );
                    })}
                </select>
              </div>
              <div className="mb-3 col-lg-6">
                <label for="exampleInputEmail1" className="form-label">
                  Grid Columns
                </label>
                <input
                  type="number"
                  className="form-control"
                  id="gridColumns"
                  aria-describedby="emailHelp"
                  max="12"
                  min="0"
                  value={gridColumns}
                  onChange={(e) => setGridColumns(e.target.value)}
                />
              </div>
              <div className="mb-3 col-lg-12">
                <label for="exampleInputPassword1" className="form-label">
                  Label English
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="exampleInputPassword1"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                />
              </div>

              <div className="mb-3 col-lg-6">
                <label for="exampleInputPassword1" className="form-label">
                  Display order
                </label>
                <input
                  type="number"
                  className="form-control"
                  id="displayOrder"
                  min="0"
                  value={displayOrder}
                  onChange={(e) => setDisplayOrder(e.target.value)}
                />
              </div>
              {controlSelected && controlSelected == "TextBox" && (
                <div className="mb-3 col-lg-6">
                  <label for="exampleInputPassword1" className="form-label">
                    Max size
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    id="maxSize"
                    min="0"
                    value={maxSize}
                    onChange={(e) => setMaxSize(e.target.value)}
                  />
                </div>
              )}
              {controlSelected && controlSelected == "DropDown" && (
                <div className="mb-3 col-lg-12">
                  <label for="exampleInputPassword1" className="form-label">
                    DropDown Details
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="exampleInputPassword1"
                    value={ddDetails}
                    onChange={(e) => setDdDetails(e.target.value)}
                  />
                  <p>write coma seperated values ex:-data1,data2,data3</p>
                </div>
              )}

              <div className="mb-3 form-check col-lg-4">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="exampleCheck1"
                  value={isMandatory}
                  onChange={(e) => setIsMandatory(e.target.checked)}
                />
                <label className="form-check-label" for="exampleCheck1">
                  Mandatory
                </label>
              </div>
              <div className="mb-3 form-check col-lg-4" hidden>
                <input
                  type="text"                  
                  id="controlId"                
                   value=""
                   ref={controlId}
                  
                />
                <label className="form-check-label" for="exampleCheck1">
                  Mandatory
                </label>
              </div>
              <div className="col-lg-12 row">
                <div className="col-lg-4">
                  <button
                    type="submit"
                    className="btn btn-primary"
                    onClick={(e) => handleSubmit(e)}
                    id="submitBtn"
                  >
                    Submit
                  </button>

                  <Link to="/" className="btn btn-primary">
                    Close
                  </Link>
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={(e) => handleClear(e)}
                  >
                    Clear
                  </button>

                  <button
                    type="button"
                    class="btn btn-primary"
                    data-bs-toggle="modal"
                    data-bs-target="#exampleModal"
                  >
                    Preview
                  </button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>

      {formDataByFormId && formDataByFormId.length > 0 && (
        <div className="card">
        <div>
            <div
              className="card-header"
            
            >
              Control Details
            </div>
          <div className="card-body">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Delete</th>
                <th scope="col">Edit</th>
                <th scope="col">ControlType</th>
                <th scope="col">Label</th>
                <th scope="col">IsCompulsory</th>
              </tr>
            </thead>
            <tbody>
              {formDataByFormId.map((item) => {
                return (
                  <tr key={item.id}>
                    <td>
                      <button onClick={()=>handleDelete(item.id)}> <DeleteIcon /> </button>
                     
                    </td>
                    <td>
                     <button onClick={()=>handleEdit(item)}><EditIcon /> </button> 
                    </td>
                    <td>{item.controlName}</td>
                    <td>{item.label}</td>
                    <td>true</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          </div>
         </div>

        </div>
      )}
      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                Modal title
              </h5>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              {formDataByFormId && formDataByFormId.length > 0 && (
                <form>
                  <div className="col-lg-12 row">
                    {formDataByFormId
                      .sort((x) => x.DisplayOrder)
                      .map((item) => {
                        return (
                          <>
                            {item.controlName === "TextBox" && (
                              <div className={"col-lg-" + item.gridColumn}>
                                <label
                                  for={item.label.trim()}
                                  class="form-label"
                                >
                                  {item.label}
                                </label>
                                <input
                                  type="text"
                                  class="form-control"
                                  id={item.label.trim()}
                                  aria-describedby="emailHelp"
                                  required={item.isMandatory}
                                  maxLength={item.maxLength}
                                
                                />
                              </div>
                            )}

                            {item.controlName === "DropDown" && (
                              <div className={"col-lg-" + item.gridColumn}>
                                <label
                                  for="dropDown"
                                  className="form-label"
                                >
                                  {item.label}
                                </label>
                                <select
                                  id="dropDown"
                                  className="form-control form-select"
                                  onChange={(e) => handleSelect(e)}
                                  required={item.isMandatory}
                                >
                                  {(ddDetailsList = item.ddList.split(","))}
                                  {ddDetailsList &&
                                    ddDetailsList.length > 0 &&
                                    ddDetailsList.map((dd) => {
                                      <option value={dd}>{dd}</option>;
                                    })}
                                </select>
                              </div>
                            )}

                            {item.controlName === "CheckBox" && (
                              <div className={"col-lg-" + item.gridColumn}>
                                <label
                                  for={item.label.trim()}
                                  class="form-label"
                                >
                                  {item.label}
                                </label>

                                <input
                                  type="checkbox"
                                  className="ms-3"
                                  id={item.label.trim()}
                                  name="vehicle1"
                                  value={true}
                                  required={item.isMandatory}
                                />
                              </div>
                            )}

                            {item.controlName === "RadioButton" && (
                              <div className={"col-lg-" + item.gridColumn}>
                                <label
                                  for={item.label.trim()}
                                  class="form-label"
                                >
                                  {item.label}
                                </label>
                                <input type="radio" required={item.isMandatory} id={item.label.trim()} value={item.label} className="ms-2"/>
                                
                              </div>
                            )}
                            {item.controlName === "File" && (
                              <div className={"col-lg-" + item.gridColumn}>
                                <label
                                  for={item.label.trim()}
                                  class="form-label"
                                >
                                  {item.label}
                                </label>
                                <input type="file" required={item.isMandatory} id={item.label.trim()} className="ms-2"/>
                                
                              </div>
                            )}
                             {item.controlName === "DateTime" && (
                              <div className={"col-lg-" + item.gridColumn}>
                                <label
                                  for={item.label.trim()}
                                  class="form-label"
                                >
                                  {item.label}
                                </label>
                                <input type="datetime-local" required={item.isMandatory}  id={item.label.trim()}/>
                                
                              </div>
                            )}
                          </>
                        );
                      })}
                  </div>
                </form>
              )}
            </div>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-bs-dismiss="modal"
            >
              Close
            </button>
            <button type="button" class="btn btn-primary">
              Save changes
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ConfigurationForm;
