import React, { useState } from "react"
import bootstrap from "bootstrap"
import {card} from 'bootstrap'
import 'bootstrap/dist/css/bootstrap.css'
import {Link} from 'react-router-dom'
const Index = () => {
  const id=Math.floor(Math.random() * 10);
  
//  const handleClick=()=>{
//   var randomNumber=Math.floor(Math.random() * 10);
//       return setId(prev=>prev.id=id+randomNumber);
     
//   }
    return (
       <>
       <div>
       <div className="card col-lg-4 mx-auto mt-5 shadow-lg rounded">
  <h5 className="card-header">Welcome</h5>
  <div className="card-body">
    <h5 className="card-title">Click below link to create configuration form</h5>
        <Link  to={{
    pathname: `/configurationform/${id}`,
    
  }}>Click here</Link>
  </div>
</div>
</div>
       </>
    );
};

export default Index;

